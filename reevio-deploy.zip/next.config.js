/** @type {import('next').NextConfig} */
const nextConfig = {
  // Configuration options here
}

module.exports = nextConfig